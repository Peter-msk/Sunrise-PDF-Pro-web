"""Check Java PDF tool responses before sending them as successful downloads."""
from __future__ import annotations

import json
from pathlib import Path


class InvalidToolOutput(ValueError):
    pass


def validate_java_result(path: Path, kind: str) -> dict:
    if not path.is_file() or path.stat().st_size == 0:
        raise InvalidToolOutput("결과 파일이 없거나 비어 있습니다")
    if kind == "info":
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
        except (UnicodeError, ValueError) as exc:
            raise InvalidToolOutput("PDF 정보 결과가 유효한 JSON이 아닙니다") from exc
        if not isinstance(data, dict) or type(data.get("pages")) is not int or not (1 <= data["pages"] <= 300):
            raise InvalidToolOutput("PDF 정보의 페이지 수가 올바르지 않습니다")
        return {"pages": data["pages"], "kind": "info"}
    try:
        import fitz
        with fitz.open(path) as doc:
            pages = len(doc)
            if doc.needs_pass or not (1 <= pages <= 300):
                raise InvalidToolOutput("암호화되었거나 허용 범위를 벗어난 PDF 결과입니다")
            # Force reading of first/last page to catch obvious broken xref trees.
            _ = doc[0].rect
            _ = doc[-1].rect
            return {"pages": pages, "kind": "pdf"}
    except InvalidToolOutput:
        raise
    except Exception as exc:
        raise InvalidToolOutput("PDF 구조가 잘못되었거나 검사할 수 없습니다") from exc
