"""Bounded rhwp SVG first-page preview and self-description adapter (no Hancom).

The third-party rhwp executable is never bundled/downloaded by this module.
Source: https://github.com/edwardkim/rhwp (MIT).
"""
from __future__ import annotations
import json
import os
import re
import subprocess
import tempfile
import threading
import time
import xml.etree.ElementTree as ET
from pathlib import Path

from opensource_converter import binary_path, _stop_process

MAX_PREVIEW_BYTES = 20 * 1024 * 1024
MAX_SVG_BYTES = 4 * 1024 * 1024
MAX_PREVIEW_SECONDS = 30
_preview_slot = threading.BoundedSemaphore(1)

class RhwpPreviewError(Exception):
    pass

def _execute(binary: Path, args: list[str], *, cwd: Path, seconds: int = 30):
    """Use argument vector, no shell, bounded exit and subprocess group cleanup."""
    with tempfile.TemporaryFile() as out, tempfile.TemporaryFile() as err:
        kwargs = {'stdin': subprocess.DEVNULL, 'stdout': out, 'stderr': err,
                  'cwd': str(cwd), 'shell': False}
        if os.name == 'nt':
            kwargs['creationflags'] = subprocess.CREATE_NEW_PROCESS_GROUP
        else:
            kwargs['start_new_session'] = True
        proc = subprocess.Popen([str(binary), *args], **kwargs)
        started = time.monotonic()
        try:
            while proc.poll() is None:
                if time.monotonic() - started > seconds:
                    raise RhwpPreviewError('RHWP_PREVIEW_TIMEOUT: 문서 검사 시간이 초과되었습니다')
                time.sleep(0.05)
            out.seek(0)
            result = out.read(256 * 1024 + 1)
            err.seek(0, 2)
            n = err.tell()
            err.seek(max(0, n - 1024))
            error_tail = err.read(1024).decode('utf-8', 'replace')
            if proc.returncode:
                raise RhwpPreviewError(f'RHWP_PREVIEW_FAILED: CLI 종료 코드 {proc.returncode} {error_tail[-200:]}')
            if len(result) > 256 * 1024:
                raise RhwpPreviewError('RHWP_MANIFEST_TOO_LARGE')
            return result
        finally:
            _stop_process(proc)

def _is_hwp_signature(raw: bytes, ext: str) -> bool:
    if ext == '.hwp':
        return raw.startswith(bytes.fromhex('D0CF11E0A1B11AE1'))
    if ext == '.hwpx':
        return raw.startswith(b'PK\x03\x04')
    return False

def _safe_svg(svg: bytes) -> bytes:
    if len(svg) > MAX_SVG_BYTES or not svg:
        raise RhwpPreviewError('RHWP_SVG_SIZE_INVALID')
    if re.search(br'<!DOCTYPE|<!ENTITY', svg, re.I):
        raise RhwpPreviewError('RHWP_SVG_UNSAFE_XML')
    try:
        root = ET.fromstring(svg)
    except ET.ParseError as exc:
        raise RhwpPreviewError('RHWP_SVG_INVALID_XML') from exc
    ns = '{http://www.w3.org/2000/svg}'
    if root.tag not in {ns + 'svg', 'svg'}:
        raise RhwpPreviewError('RHWP_SVG_INVALID_ROOT')
    banned = {'script', 'foreignObject', 'iframe', 'object', 'embed', 'audio', 'video', 'animate', 'set'}
    for node in root.iter():
        name = node.tag.rsplit('}', 1)[-1] if isinstance(node.tag, str) else ''
        if name in banned:
            raise RhwpPreviewError('RHWP_SVG_ACTIVE_CONTENT')
        if name == 'style' and node.text and re.search(r'@import|url\s*\(\s*[\'\"]?(?:https?:|//|file:|javascript:)', node.text, re.I):
            raise RhwpPreviewError('RHWP_SVG_EXTERNAL_STYLE')
        for key, value in node.attrib.items():
            attr = key.rsplit('}', 1)[-1].lower()
            v = value.strip().lower()
            if attr.startswith('on') or 'javascript:' in v or 'file:' in v:
                raise RhwpPreviewError('RHWP_SVG_UNSAFE_ATTRIBUTE')
            if attr in {'href', 'src'} and not (v.startswith('#') or re.match(r'data:image/(?:png|jpeg|jpg|gif|webp);base64,', v)):
                raise RhwpPreviewError('RHWP_SVG_EXTERNAL_REFERENCE')
            if 'url(' in v and re.search(r'url\s*\(\s*[\'\"]?(?:https?:|//|file:|javascript:)', v):
                raise RhwpPreviewError('RHWP_SVG_EXTERNAL_STYLE')
    return ET.tostring(root, encoding='utf-8', xml_declaration=True)

def preview_first_page(source: Path, output_dir: Path) -> bytes:
    if not _preview_slot.acquire(blocking=False):
        raise RhwpPreviewError('RHWP_PREVIEW_BUSY: 다른 원본 미리보기가 진행 중입니다')
    try:
        return _preview_first_page_locked(source, output_dir)
    finally:
        _preview_slot.release()

def _preview_first_page_locked(source: Path, output_dir: Path) -> bytes:
    binary = binary_path()
    if binary is None:
        raise RhwpPreviewError('RHWP_EXECUTABLE_MISSING')
    out = output_dir / 'svg'
    out.mkdir()
    stdout = _execute(binary, ['export-svg', str(source), '-o', str(out), '-p', '0', '--json'], cwd=output_dir)
    paths = []
    try:
        manifest = json.loads(stdout)
        if isinstance(manifest, dict) and isinstance(manifest.get('pages'), list):
            paths = [entry['path'] for entry in manifest['pages'] if isinstance(entry, dict) and isinstance(entry.get('path'), str)]
    except (UnicodeDecodeError, ValueError):
        pass
    if not paths:
        paths = [str(x) for x in out.glob('*.svg')]
    for name in paths:
        candidate = Path(name)
        if not candidate.is_absolute():
            # rhwp manifest can return a path relative to process cwd.
            candidate = output_dir / candidate
        candidate = candidate.resolve()
        try:
            candidate.relative_to(out.resolve())
        except ValueError:
            raise RhwpPreviewError('RHWP_SVG_PATH_OUTSIDE_WORKSPACE')
        if candidate.is_file() and candidate.suffix.lower() == '.svg':
            return _safe_svg(candidate.read_bytes() if candidate.stat().st_size <= MAX_SVG_BYTES else b'')
    raise RhwpPreviewError('RHWP_SVG_OUTPUT_MISSING')

def capabilities() -> dict:
    binary = binary_path()
    if binary is None:
        return {'available': False, 'reason': 'RHWP_EXECUTABLE_MISSING', 'verified': False}
    try:
        with tempfile.TemporaryDirectory(prefix='sunrise-rhwp-cap-') as temp:
            output = _execute(binary, ['capabilities'], cwd=Path(temp), seconds=5)
        doc = json.loads(output)
        commands = doc.get('commands', [])
        names = {entry.get('name') for entry in commands if isinstance(entry, dict)}
        required = {'export-pdf', 'export-svg'}
        return {'available': True, 'verified': bool(required <= names),
                'version': str(doc.get('version', ''))[:60],
                'schema_version': doc.get('schemaVersion'),
                'required_commands': sorted(required), 'present_commands': sorted(required & names),
                'reason': 'READY_TO_TEST' if required <= names else 'RHWP_REQUIRED_COMMANDS_MISSING'}
    except (RhwpPreviewError, OSError, ValueError, TypeError) as exc:
        return {'available': True, 'verified': False, 'reason': str(exc)[:150]}
