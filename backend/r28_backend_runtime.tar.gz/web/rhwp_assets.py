"""Local integrity gate for explicitly installed rhwp browser assets.

An asset hash is NOT proof of package publisher identity or functional accuracy.
Runtime HWP compatibility must still be verified in a real browser.
"""
from __future__ import annotations
import hashlib
import json
from pathlib import Path, PurePosixPath

MAX_MANIFEST_BYTES = 2 * 1024 * 1024
MAX_JS_BYTES = 15 * 1024 * 1024
MAX_WASM_BYTES = 100 * 1024 * 1024
MAX_FILES = 80


def _digest(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open('rb') as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b''):
            digest.update(block)
    return digest.hexdigest()


def check_assets(vendor: Path) -> dict:
    """Require a complete installer manifest and compare every installed asset.

    Treat symlinks (including the vendor directory) and malformed paths as invalid.
    Errors are deliberately generic: no local filesystem paths in HTTP output.
    """
    result = dict(installed=False, module_present=False, wasm_present=False,
                  integrity_verified=False, browser_preview='NOT_INSTALLED',
                  runtime_verified=False, version=None, issue='ASSETS_MISSING')
    try:
        if not vendor.is_dir() or vendor.is_symlink():
            return result
        js = vendor / 'rhwp.js'
        wasm = vendor / 'rhwp_bg.wasm'
        result['module_present'] = js.is_file() and not js.is_symlink() and 64 < js.stat().st_size < MAX_JS_BYTES
        result['wasm_present'] = wasm.is_file() and not wasm.is_symlink() and 1024 < wasm.stat().st_size < MAX_WASM_BYTES
        if result['wasm_present']:
            with wasm.open('rb') as wasm_handle:
                result['wasm_present'] = wasm_handle.read(4) == b'\0asm'
        if not result['module_present'] or not result['wasm_present']:
            result['issue'] = 'REQUIRED_ASSET_INVALID'
            return result
        manifest_path = vendor / 'ASSET_MANIFEST.json'
        if manifest_path.is_symlink() or not manifest_path.is_file() or manifest_path.stat().st_size > MAX_MANIFEST_BYTES:
            result['issue'] = 'MANIFEST_MISSING_OR_INVALID'
            return result
        metadata = json.loads(manifest_path.read_text(encoding='utf8'))
        result['version'] = metadata.get('version') if isinstance(metadata.get('version'), str) else None
        files = metadata.get('files')
        if metadata.get('package') != '@rhwp/core' or not isinstance(files, dict) or not 3 <= len(files) <= MAX_FILES:
            result['issue'] = 'MANIFEST_SCHEMA_INVALID'
            return result
        if not {'rhwp.js', 'rhwp_bg.wasm', 'package.json'}.issubset(files):
            result['issue'] = 'MANIFEST_REQUIRED_FILES_MISSING'
            return result
        if not any(str(n).lower().startswith(('license', 'copying')) for n in files):
            result['issue'] = 'MANIFEST_LICENSE_MISSING'
            return result
        for name, expected in files.items():
            if not isinstance(name, str) or not isinstance(expected, str) or len(expected) != 64:
                result['issue'] = 'MANIFEST_ENTRY_INVALID'
                return result
            relative = PurePosixPath(name)
            if (relative.is_absolute() or not relative.parts or '..' in relative.parts or
                    any(p in ('.', '') for p in relative.parts) or '\\' in name or ':' in name):
                result['issue'] = 'MANIFEST_PATH_INVALID'
                return result
            current = vendor.joinpath(*relative.parts)
            if (not current.is_file() or current.is_symlink() or current.stat().st_size > MAX_WASM_BYTES or
                not current.resolve().is_relative_to(vendor.resolve())):
                result['issue'] = 'ASSET_MISSING_OR_SYMLINK'
                return result
            if _digest(current) != expected.lower():
                result['issue'] = 'ASSET_HASH_MISMATCH'
                return result
        package = json.loads((vendor/'package.json').read_text(encoding='utf8'))
        if package.get('name') != '@rhwp/core' or package.get('version') != result['version']:
            result['issue'] = 'PACKAGE_IDENTITY_MISMATCH'
            return result
        result.update(installed=True, integrity_verified=True,
                      browser_preview='ASSETS_VERIFIED_RUNTIME_UNTESTED', issue='NONE')
    except (OSError, ValueError, TypeError, json.JSONDecodeError, UnicodeError):
        result['issue'] = 'ASSET_VERIFICATION_FAILED'
    return result
