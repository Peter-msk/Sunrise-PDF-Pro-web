/* R16 browser WASM viewer: local file -> worker -> sanitized SVG image. */
'use strict';
import {sanitizeRhwpSvg} from './rhwp-svg-sanitize.js';

const MAX_FILE = 20 * 1024 * 1024;
const MAX_WAIT = 30000;
export class RhwpBrowserViewer {
  constructor({onStatus, onPage, onError} = {}) {
    this.onStatus = onStatus || (() => {});
    this.onPage = onPage || (() => {});
    this.onError = onError || (() => {});
    this.worker = null;
    this.generation = 0;
    this.sequence = 0;
    this.pending = new Map();
    this.pageCount = 0;
    this.page = 0;
    this.fileName = '';
    this.previewUrl = null;
    this.busy = false;
    this.renderSequence = 0;
  }
  reset(reason = '새 문서') {
    this.generation += 1;
    this.renderSequence += 1;
    for (const pending of this.pending.values()) {
      clearTimeout(pending.timer);
      pending.reject(new Error(reason));
    }
    this.pending.clear();
    if (this.worker) { this.worker.terminate(); this.worker = null; }
    if (this.previewUrl) { URL.revokeObjectURL(this.previewUrl); this.previewUrl = null; }
    this.pageCount = 0;
    this.page = 0;
    this.fileName = '';
    this.busy = false;
  }
  createWorker() {
    const worker = new Worker('/static/rhwp-wasm-worker.js', {type: 'module', name: 'rhwp-browser'});
    worker.onmessage = event => {
      const data = event.data || {};
      const pending = this.pending.get(data.requestId);
      if (!pending) return;
      clearTimeout(pending.timer);
      this.pending.delete(data.requestId);
      if (data.type === 'error') pending.reject(new Error(`${data.code || 'RHWP_ERROR'}: ${data.message || ''}`));
      else pending.resolve(data);
    };
    worker.onerror = () => {
      const error = new Error('WASM 실행파일을 불러오지 못했습니다. 공식 @rhwp/core 패키지 설치 상태를 확인하세요.');
      for (const pending of this.pending.values()) { clearTimeout(pending.timer); pending.reject(error); }
      this.pending.clear();
      worker.terminate();
      if (this.worker === worker) this.worker = null;
    };
    this.worker = worker;
  }
  request(action, data = {}, transfer = []) {
    if (!this.worker) return Promise.reject(new Error('미리보기 엔진이 시작되지 않았습니다.'));
    const worker = this.worker;
    const requestId = ++this.sequence;
    return new Promise((resolve, reject) => {
      const timer = setTimeout(() => {
        this.pending.delete(requestId);
        if (this.worker === worker) this.reset('작업 제한시간 초과: 엔진이 종료되었습니다.');
        reject(new Error('WASM 문서 처리 제한시간(30초)을 초과했습니다.'));
      }, MAX_WAIT);
      this.pending.set(requestId, {resolve, reject, timer});
      try { worker.postMessage({requestId, action, ...data}, transfer); }
      catch (error) { clearTimeout(timer); this.pending.delete(requestId); reject(error); }
    });
  }
  async open(file) {
    if (!file || !/\.(hwp|hwpx)$/i.test(file.name) || file.size <= 0 || file.size > MAX_FILE) {
      throw new Error('HWP/HWPX 파일(0~20MiB)을 선택하세요.');
    }
    this.reset('다른 문서 선택');
    const generation = this.generation;
    this.busy = true;
    this.fileName = file.name;
    try {
      this.onStatus(`${file.name} · 브라우저 WASM 읽기 중`);
      const buffer = await file.arrayBuffer();
      if (generation !== this.generation) return;
      this.createWorker();
      const result = await this.request('open', {buffer}, [buffer]);
      if (generation !== this.generation) return;
      if (result.type !== 'opened') throw new Error('문서를 열지 못했습니다.');
      this.pageCount = result.pageCount;
      await this.render(0);
    } catch (error) {
      if (generation === this.generation) { this.reset('오류로 인한 종료'); this.onError(error); }
      throw error;
    } finally {
      if (generation === this.generation) this.busy = false;
    }
  }
  async render(page) {
    if (!this.worker || !Number.isInteger(page) || page < 0 || page >= this.pageCount) return;
    const generation = this.generation;
    const renderSequence = ++this.renderSequence;
    const result = await this.request('render', {page});
    // A slow old render must never replace a newer page.
    if (generation !== this.generation || renderSequence !== this.renderSequence) return;
    if (result.type !== 'page') throw new Error('페이지 렌더링 결과가 없습니다.');
    // Never innerHTML/DOM-inject any upstream SVG.
    const safeSvg = sanitizeRhwpSvg(result.svg);
    const url = URL.createObjectURL(new Blob([safeSvg], {type:'image/svg+xml'}));
    const previous = this.previewUrl;
    this.previewUrl = url;
    this.page = page;
    this.onPage({url, page, pageCount:this.pageCount, fileName:this.fileName});
    if (previous) URL.revokeObjectURL(previous);
  }
}
