/* R16 Browser-only rhwp WASM document viewer. Document bytes never leave this Worker. */
'use strict';
let documentRef = null;
let initialized = false;
let fontCanvas = null;
let fontContext = null;
let lastFont = '';
const MAX_BYTES = 20 * 1024 * 1024;
const MAX_PAGES = 500;
const MAX_SVG_CHARS = 4 * 1024 * 1024;

function fail(requestId, code, message) {
  self.postMessage({requestId, type: 'error', code, message: String(message).slice(0, 360)});
}
function width(font, text) {
  if (!fontContext) {
    if (typeof OffscreenCanvas === 'undefined') throw new Error('OFFSCREEN_CANVAS_UNAVAILABLE');
    fontCanvas = new OffscreenCanvas(1, 1);
    fontContext = fontCanvas.getContext('2d');
    if (!fontContext) throw new Error('CANVAS_2D_UNAVAILABLE');
  }
  if (font !== lastFont) { fontContext.font = font; lastFont = font; }
  return fontContext.measureText(text).width;
}
async function initialize() {
  if (initialized) return;
  // Upstream API contract: rhwp.js + rhwp_bg.wasm, vendor installed explicitly.
  const pkg = await import('./vendor/rhwp/rhwp.js');
  if (typeof pkg.default !== 'function' || typeof pkg.HwpDocument !== 'function') {
    throw new Error('RHWP_WASM_API_INCOMPATIBLE');
  }
  self.measureTextWidth = width;
  await pkg.default({module_or_path: '/static/vendor/rhwp/rhwp_bg.wasm'});
  self.RhwpDocumentClass = pkg.HwpDocument;
  initialized = true;
}
self.onmessage = async event => {
  const {requestId, action} = event.data || {};
  if (!Number.isInteger(requestId) || requestId < 1) return;
  try {
    if (action === 'open') {
      const buffer = event.data.buffer;
      if (!(buffer instanceof ArrayBuffer) || buffer.byteLength === 0 || buffer.byteLength > MAX_BYTES) {
        return fail(requestId, 'INVALID_DOCUMENT_SIZE', '문서가 비어 있거나 브라우저 열람 제한(20MiB)을 초과했습니다.');
      }
      // Release the previous document before loading any new input.
      if (documentRef && typeof documentRef.free === 'function') documentRef.free();
      documentRef = null;
      await initialize();
      const newDoc = new self.RhwpDocumentClass(new Uint8Array(buffer));
      const count = Number(newDoc.pageCount());
      if (!Number.isInteger(count) || count < 1 || count > MAX_PAGES) {
        if (typeof newDoc.free === 'function') newDoc.free();
        return fail(requestId, 'INVALID_PAGE_COUNT', '문서 페이지 수가 지원 범위를 벗어났습니다.');
      }
      documentRef = newDoc;
      self.postMessage({requestId, type: 'opened', pageCount: count});
    } else if (action === 'render') {
      if (!documentRef) return fail(requestId, 'DOCUMENT_NOT_LOADED', '먼저 문서를 여세요.');
      const page = Number(event.data.page);
      if (!Number.isInteger(page) || page < 0 || page >= documentRef.pageCount()) {
        return fail(requestId, 'INVALID_PAGE_INDEX', '올바르지 않은 페이지 번호입니다.');
      }
      const svg = documentRef.renderPageSvg(page);
      if (typeof svg !== 'string' || svg.length < 20 || svg.length > MAX_SVG_CHARS) {
        return fail(requestId, 'SVG_SIZE_LIMIT', '렌더링 결과가 비어 있거나 4MiB를 초과했습니다.');
      }
      self.postMessage({requestId, type: 'page', page, svg});
    } else if (action === 'dispose') {
      if (documentRef && typeof documentRef.free === 'function') documentRef.free();
      documentRef = null;
      self.postMessage({requestId, type: 'disposed'});
      self.close();
    } else {
      fail(requestId, 'INVALID_ACTION', '지원하지 않는 WASM 작업입니다.');
    }
  } catch (err) {
    // Avoid leaking original text, buffer contents or internal file paths in errors.
    const code = String(err && err.message || '').startsWith('RHWP_WASM_') ? String(err.message) : 'RHWP_WASM_FAILURE';
    fail(requestId, code, code === 'RHWP_WASM_FAILURE' ? '문서 분석 또는 렌더링 실패: 파일·글꼴·엔진 버전을 확인하세요.' : 'rhwp 브라우저 엔진 API가 호환되지 않습니다.');
  }
};
