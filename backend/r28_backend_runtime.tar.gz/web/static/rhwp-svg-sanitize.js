/* SVG reduced to safe graphics-only subtree before rendering in an <img>. */
'use strict';
const SVG_NS = 'http://www.w3.org/2000/svg';
const allowed = new Set([
  'svg','g','defs','symbol','path','rect','circle','ellipse','line','polyline','polygon',
  'text','tspan','textpath','image','clippath','mask','lineargradient','radialgradient',
  'stop','pattern','marker','filter','fegaussianblur','feoffset','feblend','fecolormatrix',
  'fecomposite','femerge','femergenode','fecomponenttransfer','fefuncalpha','fefuncr',
  'fefuncg','fefuncb'
]);
const attributes = new Set([
  'id','class','xmlns','width','height','viewbox','preserveaspectratio','x','y','x1','y1',
  'x2','y2','cx','cy','r','rx','ry','d','points','fill','fill-rule','stroke','stroke-width',
  'stroke-linecap','stroke-linejoin','stroke-dasharray','stroke-dashoffset','stroke-opacity',
  'fill-opacity','opacity','transform','font-family','font-size','font-weight','font-style',
  'text-anchor','letter-spacing','dominant-baseline','baseline-shift','dx','dy','rotate',
  'clip-path','mask','filter','offset','stop-color','stop-opacity','gradientunits',
  'gradienttransform','spreadmethod','patternunits','patterncontentunits','patterntransform',
  'markerwidth','markerheight','refx','refy','orient','maskunits','maskcontentunits',
  'stddeviation','in','in2','result','mode','type','values','slope','intercept','amplitude',
  'exponent','k1','k2','k3','k4','operator','color','color-interpolation-filters',
  'paint-order','vector-effect','shape-rendering','text-rendering','pointer-events',
  'display','visibility','style','href'
]);
const cssAllow = new Set(['font-family','font-size','font-weight','font-style','letter-spacing',
  'fill','stroke','stroke-width','stroke-linecap','stroke-linejoin','stroke-dasharray',
  'text-anchor','dominant-baseline','opacity','fill-opacity','stroke-opacity',
  'paint-order','shape-rendering','text-rendering','color']);
function safeRef(value) { return /^url\(\s*['"]?#[\w.:-]+['"]?\s*\)$/i.test(value); }
function safeCss(value) {
  const list=[];
  for (const rule of value.split(';')) {
    if (!rule.trim()) continue;
    const idx=rule.indexOf(':');
    if (idx<1) continue;
    const key=rule.slice(0,idx).trim().toLowerCase();
    const v=rule.slice(idx+1).trim();
    if (!cssAllow.has(key) || !v || /[<>\\{}@]|expression\s*\(|javascript:|data:|\/\*/i.test(v)) continue;
    if (/url\s*\(/i.test(v) && !safeRef(v)) continue;
    list.push(`${key}:${v}`);
  }
  return list.join(';');
}
export function sanitizeRhwpSvg(source) {
  if (typeof source !== 'string' || source.length < 20 || source.length > 4 * 1024 * 1024) throw new Error('SVG 크기 제한 초과');
  const parsed = new DOMParser().parseFromString(source, 'image/svg+xml');
  const root = parsed.documentElement;
  if (!root || root.localName.toLowerCase() !== 'svg' || root.namespaceURI !== SVG_NS || parsed.querySelector('parsererror')) throw new Error('SVG 형식 오류');
  let count=0;
  function copy(node, doc) {
    if (node.nodeType === Node.TEXT_NODE) return doc.createTextNode(node.nodeValue || '');
    if (node.nodeType !== Node.ELEMENT_NODE || node.namespaceURI !== SVG_NS) return null;
    const tag=node.localName.toLowerCase();
    if (!allowed.has(tag)) return null;
    if (++count > 50000) throw new Error('SVG 노드 개수 제한 초과');
    const element=doc.createElementNS(SVG_NS, node.localName);
    for (const attr of node.attributes) {
      const key=attr.localName.toLowerCase();
      if (!attributes.has(key) || /^on/i.test(key)) continue;
      let value=attr.value;
      if (value.length > 8192 || /[<>]/.test(value)) continue;
      if (key === 'href') {
        if (tag !== 'image' || !/^data:image\/(?:png|jpeg|webp);base64,[a-z\d+/=]+$/i.test(value) || value.length>2*1024*1024) continue;
      } else if (key === 'style') {
        value=safeCss(value); if (!value) continue;
      } else if (/url\s*\(/i.test(value) && !safeRef(value)) continue;
      else if (/javascript:|data:text|@import|expression\s*\(/i.test(value)) continue;
      element.setAttribute(key === 'viewbox' ? 'viewBox' : key, value);
    }
    for (const child of node.childNodes) {
      const next=copy(child,doc); if(next) element.appendChild(next);
    }
    return element;
  }
  const clean=document.implementation.createDocument(SVG_NS,'svg',null);
  clean.replaceChild(copy(root,clean), clean.documentElement);
  clean.documentElement.setAttribute('xmlns', SVG_NS);
  return new XMLSerializer().serializeToString(clean);
}
