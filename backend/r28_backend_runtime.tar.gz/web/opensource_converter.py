"""rhwp HWP/HWPX -> PDF conversion. Portable builds use only verified bundled CLI."""
from __future__ import annotations

import os
import sys
import json
import hashlib
import shutil
import signal
import subprocess
import tempfile
import time
from pathlib import Path
from types import SimpleNamespace
from typing import Callable, Iterable

MAX_SECONDS_PER_FILE = 120
POLL_SECONDS = 0.10


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open('rb') as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b''):
            digest.update(chunk)
    return digest.hexdigest()


def bundled_binary(bundle_root: Path) -> Path | None:
    """Never trust PATH/env in a frozen end-user build; verify our bundled binary.

    This is an integrity check against a local manifest, not an authenticity
    signature. The source archive hash is verified on the maintainer's build host.
    """
    executable = bundle_root / 'engines' / 'rhwp' / ('rhwp.exe' if os.name == 'nt' else 'rhwp')
    manifest_path = bundle_root / 'PORTABLE_ASSETS.json'
    try:
        if not executable.is_file() or executable.is_symlink() or manifest_path.is_symlink():
            return None
        data = json.loads(manifest_path.read_text(encoding='utf-8'))
        expected = data['files']['engines/rhwp/' + executable.name]
        if not isinstance(expected, str) or len(expected) != 64:
            return None
        if _sha256(executable) != expected.lower():
            return None
        if os.name != 'nt' and not os.access(executable, os.X_OK):
            return None
        return executable.resolve()
    except (OSError, ValueError, TypeError, KeyError, json.JSONDecodeError):
        return None


def binary_path() -> Path | None:
    # Frozen packages are self-contained. Do not accidentally substitute a
    # system-installed or attacker-controlled rhwp executable.
    if getattr(sys, 'frozen', False):
        return bundled_binary(Path(sys.executable).resolve().parent)
    configured = os.getenv('SUNRISE_RHWP_CLI', '').strip()
    selected = configured if configured else shutil.which('rhwp')
    if not selected:
        return None
    path = Path(selected).expanduser().resolve()
    if not path.is_file() or (os.name != 'nt' and not os.access(path, os.X_OK)):
        return None
    return path


def readiness() -> dict:
    binary = binary_path()
    bundled = bool(getattr(sys, 'frozen', False))
    return {
        'engine': 'rhwp', 'available': binary is not None,
        'hancom_required': False,
        'pdf_export_supported_by_upstream': True,
        'conversion_verified_on_this_host': False,
        'bundled_mode': bundled,
        'reason': 'READY_TO_TEST' if binary else ('BUNDLED_ENGINE_INVALID' if bundled else 'RHWP_EXECUTABLE_MISSING'),
        'setup': ('제품에 포함된 rhwp 엔진 검증 결과를 확인하세요.' if bundled
                  else '개발 환경에서만 SUNRISE_RHWP_CLI 경로를 지정합니다. 사용자 배포본에는 엔진을 동봉합니다.'),
    }


def _stop_process(proc: subprocess.Popen) -> None:
    if proc.poll() is not None:
        return
    try:
        if os.name == 'nt':
            proc.terminate()
        else:
            os.killpg(proc.pid, signal.SIGTERM)
        proc.wait(timeout=2)
    except (ProcessLookupError, OSError, subprocess.TimeoutExpired):
        if proc.poll() is None:
            try:
                if os.name == 'nt':
                    proc.kill()
                else:
                    os.killpg(proc.pid, signal.SIGKILL)
            except (ProcessLookupError, OSError):
                pass
            try:
                proc.wait(timeout=2)
            except subprocess.TimeoutExpired:
                pass


def _run_one(binary: Path, source: Path, output: Path, stop_event,
             pause_event, timeout_seconds: int, *, process_limits=None) -> None:
    """Bound a native conversion by elapsed time, allow cancellation, no shell."""
    if stop_event.is_set():
        raise InterruptedError('사용자 중지 요청')
    if output.exists():
        raise FileExistsError('기존 출력 파일을 덮어쓰지 않습니다')
    args = [str(binary), 'export-pdf', str(source), '-o', str(output)]
    if process_limits is not None:
        # Production runs bubblewrap with only the job workspace mounted.
        # Dev HTTP continues to use R24 prlimit for synthetic CLI tests.
        if getattr(process_limits, 'bubblewrap', None):
            args = process_limits.wrap(args, executable=binary, workspace=source.parent)
        else:
            args = process_limits.wrap(args)
    # Prevent the child process inheriting web authentication/configuration
    # secrets from SUNRISE_WEB_USERS_FILE, service tokens, or cloud credentials.
    child_env = {'PATH': '/usr/bin:/bin', 'LANG': 'C.UTF-8', 'LC_ALL': 'C.UTF-8',
                 'HOME': str(output.parent), 'TMPDIR': '/tmp', 'RUST_BACKTRACE': '0'}
    if process_limits is None and os.getenv('RHWP_STUB_VALID_PDF'):
        child_env['RHWP_STUB_VALID_PDF'] = os.environ['RHWP_STUB_VALID_PDF']
    kwargs = {'stdin': subprocess.DEVNULL, 'stdout': subprocess.DEVNULL,
              'cwd': str(output.parent), 'shell': False, 'env': child_env}
    if os.name == 'nt':
        kwargs['creationflags'] = subprocess.CREATE_NEW_PROCESS_GROUP
    else:
        kwargs['start_new_session'] = True
    started = time.monotonic()
    with tempfile.TemporaryFile() as errors:
        proc = subprocess.Popen(args, stderr=errors, **kwargs)
        try:
            while proc.poll() is None:
                if stop_event.is_set():
                    raise InterruptedError('사용자 중지 요청')
                if time.monotonic() - started > timeout_seconds:
                    raise TimeoutError(f'rhwp 변환 제한시간 {timeout_seconds}초 초과')
                time.sleep(POLL_SECONDS)
            if proc.returncode != 0:
                errors.seek(0, 2)
                end = errors.tell()
                errors.seek(max(0, end - 1500))
                detail = errors.read(1500).decode('utf-8', 'replace').strip()
                raise RuntimeError(f'rhwp 종료 코드 {proc.returncode}: {detail[-600:]}')
        finally:
            _stop_process(proc)
    if not output.is_file() or output.stat().st_size == 0:
        raise RuntimeError('rhwp가 결과 PDF를 만들지 않았습니다')


def convert(files: Iterable[Path], output_dir: Path, *, stop_event,
            pause_event, on_file: Callable[[str, str], None],
            on_progress: Callable[[float], None], merge_pdf: bool = False,
            timeout_seconds: int = MAX_SECONDS_PER_FILE, process_limits=None):
    binary = binary_path()
    if binary is None:
        raise RuntimeError('RHWP_EXECUTABLE_MISSING: 한컴 미설치 변환 엔진 rhwp 실행파일을 찾을 수 없습니다')
    files = list(files)
    output_dir = Path(output_dir).resolve()
    output_dir.mkdir(exist_ok=True, parents=True)
    timeout_seconds = max(15, min(MAX_SECONDS_PER_FILE, int(timeout_seconds)))
    outputs: list[str] = []
    errors: list[str] = []
    success = 0
    failure = 0
    for i, source in enumerate(files, 1):
        if stop_event.is_set():
            break
        while not pause_event.is_set():
            if stop_event.is_set():
                break
            time.sleep(POLL_SECONDS)
        if stop_event.is_set():
            break
        if source.suffix.lower() not in {'.hwp', '.hwpx'} or not source.is_file():
            failure += 1
            errors.append(f'{source.name}: 입력 문서가 유효하지 않습니다')
            on_file(str(source), '실패')
            continue
        # Unambiguous output names; never overwrite, even if source stems match.
        output = output_dir / f'{i:03d}_{source.stem}.pdf'
        on_file(str(source), '변환 중')
        try:
            _run_one(binary, source, output, stop_event, pause_event, timeout_seconds,
                     process_limits=process_limits)
            success += 1
            outputs.append(str(output))
            on_file(str(source), '완료')
        except InterruptedError:
            output.unlink(missing_ok=True)
            on_file(str(source), '중단')
            break
        except Exception as exc:
            output.unlink(missing_ok=True)
            failure += 1
            errors.append(f'{source.name}: {type(exc).__name__}: {str(exc)[:250]}')
            on_file(str(source), '실패')
        on_progress(i / max(1, len(files)))

    merged = None
    if merge_pdf and len(outputs) > 1 and not stop_event.is_set():
        try:
            import fitz
            dest = output_dir / 'Sunrise_merged.pdf'
            doc = fitz.open()
            try:
                for name in outputs:
                    with fitz.open(name) as part:
                        doc.insert_pdf(part)
                doc.save(str(dest))
            finally:
                doc.close()
            merged = str(dest)
        except Exception as exc:
            errors.append(f'병합 실패: {type(exc).__name__}: {str(exc)[:240]}')
            failure += 1
    return SimpleNamespace(success_count=success, fail_count=failure,
                           fail_details=errors, output_paths=outputs,
                           merged_pdf_path=merged, stopped=stop_event.is_set())
