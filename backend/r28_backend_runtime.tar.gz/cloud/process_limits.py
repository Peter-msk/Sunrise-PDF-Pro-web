"""Mandatory Linux kernel resource limits for web-service rhwp subprocesses.

prlimit caps CPU, virtual address space, output size and open files. This is
NOT filesystem, network, or syscall isolation; production deployment must
also use a separate non-root container with no network access for conversion.
"""
from __future__ import annotations

import shutil
import sys
from dataclasses import dataclass

MEMORY_BYTES = 3 * 1024 ** 3
OUTPUT_BYTES = 256 * 1024 ** 2
MAX_OPEN_FILES = 256


@dataclass(frozen=True)
class ProcessLimits:
    executable: str
    cpu_seconds: int
    memory_bytes: int = MEMORY_BYTES
    output_bytes: int = OUTPUT_BYTES

    def wrap(self, args: list[str]) -> list[str]:
        if not args or not all(isinstance(x, str) for x in args):
            raise ValueError('INVALID_COMMAND_VECTOR')
        if not 10 <= self.cpu_seconds <= 300:
            raise ValueError('INVALID_CPU_LIMIT')
        if not (512 * 1024**2 <= self.memory_bytes <= 8 * 1024**3):
            raise ValueError('INVALID_MEMORY_LIMIT')
        if not (1024**2 <= self.output_bytes <= 1024**3):
            raise ValueError('INVALID_OUTPUT_LIMIT')
        return [self.executable, f'--as={self.memory_bytes}',
                f'--cpu={self.cpu_seconds}', f'--fsize={self.output_bytes}',
                f'--nofile={MAX_OPEN_FILES}', '--core=0', '--', *args]


def readiness(timeout_seconds: int = 120) -> dict:
    binary = shutil.which('prlimit') if sys.platform.startswith('linux') else None
    ready = bool(binary)
    return {'ready': ready,
            'type': 'linux-prlimit' if ready else 'unavailable',
            'memory_limit_mib': MEMORY_BYTES // 1024**2,
            'output_limit_mib': OUTPUT_BYTES // 1024**2,
            'cpu_limit_seconds': min(300, max(15, int(timeout_seconds) + 15)),
            'is_full_sandbox': False,
            'reason': 'READY' if ready else 'PROCESS_LIMITS_UNAVAILABLE'}


def required(timeout_seconds: int = 120) -> ProcessLimits:
    check = readiness(timeout_seconds)
    if not check['ready']:
        raise RuntimeError('PROCESS_LIMITS_UNAVAILABLE')
    return ProcessLimits(shutil.which('prlimit'), check['cpu_limit_seconds'])
