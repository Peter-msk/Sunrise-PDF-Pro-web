'use strict';
(()=>{
 const $=id=>document.getElementById(id), label=(id,value)=>{$(id).textContent=String(value)};
 let csrf='',selected=null,viewer=null,job=null,timer=null,engine=false,wasm=false;
 const offline=location.protocol==='file:';
 async function api(path, opts={}){
   const method=opts.method||'GET', head={...(opts.headers||{})};
   if(method!=='GET'){head['X-Sunrise-CSRF']=csrf;}
   const r=await fetch(path,{credentials:'same-origin',cache:'no-store',...opts,headers:head});
   if(!r.ok){let reason=String(r.status);try{const payload=await r.json();reason=payload.detail||reason;}catch{}throw Error(reason);}
   return opts.raw?r:r.json();
 }
 function status(message){label('feedback',message)}
 function sync(){ $('convert').disabled=!selected||!engine||!csrf; $('preview').disabled=!selected||!wasm||!csrf; $('cancel').disabled=!job||!['queued','running'].includes(job.state); }
 function fileChosen(file){
   if(!file||!/^.+\.(hwp|hwpx)$/i.test(file.name)||file.size===0||file.size>20*1024*1024){selected=null;label('picked','HWP/HWPX 문서 20MiB 이하만 선택할 수 있습니다.');}
   else{selected=file;label('picked',`${file.name} · ${(file.size/1024/1024).toFixed(2)}MB`);}
   sync();
 }
 $('file').addEventListener('change',e=>fileChosen(e.target.files[0]));
 const drop=$('drop');['dragover','dragleave','drop'].forEach(event=>drop.addEventListener(event,e=>{e.preventDefault();drop.classList.toggle('drag',event==='dragover');if(event==='drop')fileChosen(e.dataTransfer.files[0]);}));
 async function statusCheck(){
   try {const s=await api('/api/status');
     engine=Boolean(s.rhwp_cli_available && s.process_limits?.ready);
     wasm=Boolean(s.wasm_assets_verified);
     const policy=s.process_limits?.mode==='production-bubblewrap'?'격리 운영 모드':'로컬 개발 모드';
     const reason=s.rhwp_cli_contract_reason||'';
     const contractFail=!s.rhwp_cli_available && s.rhwp_cli_file_present;
     const advisory=contractFail
       ? (reason==='RHWP_DEPLOYMENT_SHA256_UNVERIFIED'?'rhwp 배포 파일 무결성 미확인':
          reason==='RHWP_CLI_VERSION_MISMATCH'?'rhwp 버전 불일치':
          reason==='RHWP_PDF_CAPABILITY_MISSING'?'PDF 변환 명령 검증 실패':'rhwp CLI 계약 확인 실패')
       : !s.rhwp_cli_available?'서버 변환 엔진 미준비':`${policy} · 변환 보호 미준비`;
     label('engineStatus',engine?`rhwp · ${policy} 준비됨`:advisory);
     label('serviceBadge',engine?'변환 서버 연결':'변환 사용 불가');
     status(engine?'변환 서버와 연결됐습니다. 실제 문서를 시험하세요.':
       contractFail?`${advisory}. 서버 운영자의 엔진 검증이 필요합니다.`:
       !s.rhwp_cli_available?'rhwp 엔진을 서버 운영자가 준비해야 합니다.':
       '변환 실행 격리 또는 자원 보호가 준비되지 않아 작업을 접수할 수 없습니다.');}
   catch(e){engine=false;wasm=false;status(`서비스 점검 오류: ${e.message}`);}sync();
 }
 async function loadJobs(){if(!csrf)return;try{const res=await api('/api/jobs');const list=$('jobs');list.replaceChildren();
   for(const j of res.jobs){const row=document.createElement('div');row.className='jobrow';const name=document.createElement('strong');name.textContent=j.file;
   const desc=document.createElement('span');desc.textContent=`${j.state} · ${j.percent}%`;row.append(name,desc);
   if(j.download){const link=document.createElement('a');link.href=j.download;link.textContent='PDF 받기';link.rel='noopener';row.append(link);}
   if(j.retryable){const btn=document.createElement('button');btn.type='button';btn.className='outline mini';btn.textContent='안전 재시도';btn.addEventListener('click',async()=>{try{const next=await api(`/api/jobs/${j.id}/retry`,{method:'POST'});job=next;$('download').hidden=true;btn.disabled=true;status('원본 해시 확인 후 재시도를 접수했습니다.');await poll();if(!timer)timer=setInterval(poll,1300);await loadJobs();}catch(e){status(`재시도 거부: ${e.message}`);}});row.append(btn);}
   list.append(row);}if(!res.jobs.length){const p=document.createElement('p');p.className='muted';p.textContent='아직 변환한 문서가 없습니다.';list.append(p);}}
   catch(e){status(`내 작업 조회 오류: ${e.message}`);}}
 async function poll(){if(!job)return;try{const result=await api(`/api/jobs/${job.id}`);job=result;label('stage',job.state);$('progressFill').style.width=`${job.percent}%`;sync();
   if(['completed','failed','cancelled','interrupted'].includes(job.state)){clearInterval(timer);timer=null;
     if(job.state==='completed'){$('download').href=job.download;$('download').hidden=false;status(`변환 완료 · ${job.pages}쪽 · PDF 다운로드 가능`);
       const frame=document.createElement('iframe');frame.src=job.download;frame.title='변환 PDF 미리보기';$('canvas').replaceChildren(frame);
     }else status(`변환 ${job.state} · ${job.error||'추가 결과 없음'}`);loadJobs();}
   else status(`${job.file} · ${job.state} (${job.percent}%)`);
 }catch(e){clearInterval(timer);timer=null;status(`조회 오류: ${e.message}`);}}
 $('convert').addEventListener('click',async()=>{
   if(!selected||!engine||!csrf)return;const body=new FormData();body.append('file',selected);
   $('convert').disabled=true;$('download').hidden=true;status('파일을 서버로 안전하게 전송하는 중...');
   try{job=await api('/api/jobs',{method:'POST',body});label('stage','접수됨');sync();await poll();if(!timer&&job&&!['completed','failed','cancelled','interrupted'].includes(job.state))timer=setInterval(poll,1300);}
   catch(e){
     const reason=String(e.message||'');
     const advice=reason.startsWith('INVALID_HWPX_')
       ? 'HWPX 내부 구성이나 압축 안전검사를 통과하지 못했습니다. 원본 문서를 확인하세요.'
       : reason.includes('RHWP_ENGINE_NOT_INSTALLED')
       ? '서버의 변환 엔진이 준비되지 않았습니다. 운영자에게 문의하세요.'
       : reason.includes('RHWP_CLI_') || reason.includes('RHWP_DEPLOYMENT_SHA256_UNVERIFIED')
       ? '서버의 rhwp 엔진 버전·기능 검증이 통과하지 못했습니다. 운영자에게 문의하세요.'
       : reason.includes('PROCESS_LIMITS_UNAVAILABLE') || reason.includes('PRODUCTION_SANDBOX_UNAVAILABLE')
       ? '서버 변환 실행 격리·자원 보호가 준비되지 않았습니다. 운영자에게 문의하세요.'
       : reason;
     status(`변환 요청 실패: ${advice}`);
   }finally{sync();}
 });
 $('cancel').addEventListener('click',async()=>{if(job)try{await api(`/api/jobs/${job.id}/cancel`,{method:'POST'});status('중단을 요청했습니다.');}catch(e){status(e.message)}});
 $('refresh').addEventListener('click',loadJobs);
 $('preview').addEventListener('click',async()=>{if(!selected||!wasm)return;try{if(viewer)viewer.reset();
   const mod=await import('/static/rhwp-browser.js');viewer=new mod.RhwpBrowserViewer({onStatus:status,onError:e=>status(`미리보기 오류: ${e.message}`),
     onPage:({url,page,pageCount})=>{const img=document.createElement('img');img.src=url;img.alt=`${page+1}쪽 원본`; $('canvas').replaceChildren(img);label('pageIndicator',`${page+1}/${pageCount}`);$('prev').disabled=page===0;$('next').disabled=page+1===pageCount;}});
   await viewer.open(selected);status('원본 페이지 열람 완료 · 서버로 원본을 보내지 않았습니다.');
 }catch(e){status(`미리보기 실패: ${e.message}`);}});
 $('prev').addEventListener('click',()=>viewer?.render(viewer.page-1));$('next').addEventListener('click',()=>viewer?.render(viewer.page+1));
 async function authenticated(data){csrf=data.csrf;label('who',data.user);$('loginLayer').hidden=true;$('logout').hidden=false;await statusCheck();await loadJobs();}
 $('loginForm').addEventListener('submit',async e=>{e.preventDefault();if(offline)return;
   $('loginButton').disabled=true;label('loginError','');
   try{const res=await api('/api/auth/login',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({username:$('username').value,password:$('password').value})});
     $('password').value='';await authenticated(res);
   }catch(e){label('loginError',`로그인 실패: ${e.message}`);}finally{$('loginButton').disabled=false;}});
 $('logout').addEventListener('click',async()=>{try{await api('/api/auth/logout',{method:'POST'});}catch{}location.reload();});
 if(offline){label('loginError','HTML 미리보기 모드입니다. 실제 로그인과 변환은 웹 서버에서만 가능합니다.');$('loginButton').disabled=true;label('serviceBadge','HTML 미리보기');}
 else api('/api/session').then(authenticated).catch(()=>{label('loginError','웹서비스 계정으로 로그인하세요.');});
 sync();
})();
