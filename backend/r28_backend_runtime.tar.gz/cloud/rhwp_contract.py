"""R27: production-only, isolated rhwp CLI identity and PDF export contract probe.

This verifies the official v0.8.7 command surface, NOT the quality of an HWP
conversion. The caller must independently verify the pinned executable digest.
Every probe runs under the same network-disabled Linux namespaces as production
conversion; never execute untrusted uploaded files during readiness checks.
"""
from __future__ import annotations

import json
import os
from pathlib import Path
import re
import shutil
import subprocess
from functools import lru_cache

from cloud.worker_isolation import probe_bubblewrap
from cloud.process_limits import required as limits_required

MAX_PROBE_BYTES = 256 * 1024
PROBE_TIMEOUT = 5


def _run_isolated(executable: Path, arguments: tuple[str, ...]) -> str:
    bwrap = shutil.which('bwrap')
    if not bwrap or not probe_bubblewrap(bwrap):
        raise RuntimeError('RHWP_CLI_PROBE_ISOLATION_UNAVAILABLE')
    if executable.is_symlink() or not executable.is_file():
        raise RuntimeError('RHWP_CLI_PATH_INVALID')
    cmd = [bwrap, '--die-with-parent', '--unshare-all', '--new-session',
           '--tmpfs', '/', '--dir', '/usr', '--dir', '/etc', '--dir', '/opt',
           '--dir', '/opt/sunrise', '--proc', '/proc', '--dev', '/dev',
           '--tmpfs', '/tmp']
    for directory in ('/usr', '/bin', '/lib', '/lib64', '/etc/fonts', '/etc/ssl/certs'):
        if Path(directory).exists():
            cmd.extend(['--ro-bind', directory, directory])
    cmd.extend(['--ro-bind', str(executable), '/opt/sunrise/rhwp',
                '--chdir', '/tmp', '--setenv', 'HOME', '/tmp', '--',
                '/opt/sunrise/rhwp', *arguments])
    # A self-describing CLI probe must have the same CPU/RAM limits as a job.
    # No arbitrary shell, writable host mount, inherited credentials or network.
    cmd = limits_required(15).wrap(cmd)
    try:
        completed = subprocess.run(cmd, input=b'', capture_output=True,
                                   timeout=PROBE_TIMEOUT, check=False,
                                   env={'PATH': '/usr/bin:/bin', 'LANG': 'C.UTF-8',
                                        'LC_ALL': 'C.UTF-8', 'RUST_BACKTRACE': '0'})
    except subprocess.TimeoutExpired as exc:
        raise RuntimeError('RHWP_CLI_PROBE_TIMEOUT') from exc
    except OSError as exc:
        raise RuntimeError('RHWP_CLI_PROBE_START_FAILED') from exc
    if completed.returncode != 0:
        raise RuntimeError('RHWP_CLI_PROBE_NONZERO_EXIT')
    if len(completed.stdout) > MAX_PROBE_BYTES:
        raise RuntimeError('RHWP_CLI_PROBE_OUTPUT_TOO_LARGE')
    return completed.stdout.decode('utf-8', 'strict').strip()


@lru_cache(maxsize=8)
def _probe_contract(executable: str, verified_digest: str, expected_version: str) -> dict:
    # Cache is keyed by the digest already revalidated by the caller for every
    # request; therefore a modified executable never reuses a previous result.
    if re.fullmatch(r'[0-9a-f]{64}', verified_digest) is None:
        return {'verified': False, 'reason': 'RHWP_DEPLOYMENT_SHA256_UNVERIFIED'}
    if re.fullmatch(r'\d+\.\d+\.\d+', expected_version) is None:
        return {'verified': False, 'reason': 'RHWP_EXPECTED_VERSION_INVALID'}
    try:
        output = _run_isolated(Path(executable), ('--version',))
        if output != 'rhwp v' + expected_version:
            return {'verified': False, 'reason': 'RHWP_CLI_VERSION_MISMATCH'}
        # Official rhwp v0.8.7: `capabilities --json` without `--search` is
        # a usage error. Use the documented machine-readable search command.
        raw = _run_isolated(Path(executable),
                            ('capabilities', '--search', 'export-pdf', '--json'))
        obj = json.loads(raw)
        if not isinstance(obj, dict) or obj.get('tool') != 'rhwp' or \
           obj.get('version') not in {expected_version, 'v'+expected_version} or \
           obj.get('search') != 'export-pdf' or not isinstance(obj.get('commands'), list) or \
           not any(isinstance(x, dict) and x.get('name') == 'export-pdf'
                   for x in obj['commands']):
            return {'verified': False, 'reason': 'RHWP_PDF_CAPABILITY_MISSING'}
        return {'verified': True, 'reason': 'RHWP_CLI_CONTRACT_OK',
                'version': expected_version}
    except (RuntimeError, ValueError, UnicodeError, json.JSONDecodeError) as exc:
        reason = str(exc) if isinstance(exc, RuntimeError) and str(exc).startswith('RHWP_') else 'RHWP_CLI_CONTRACT_INVALID'
        return {'verified': False, 'reason': reason}


def verify_cli_contract(binary: Path, verified_digest: str, expected_version: str = '0.8.7') -> dict:
    """Check contract only after the caller verified binary SHA-256."""
    return _probe_contract(str(binary), verified_digest.lower(), expected_version)
