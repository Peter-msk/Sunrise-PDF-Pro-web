"""R25: fail-closed production converter process isolation.

Development-local HTTP retains the R24 resource-limited subprocess so existing
integration tests run without user namespace support. Public HTTPS requires
Linux bubblewrap namespace isolation AND prlimit; this module never treats
simple resource limits as production sandboxing.

There is no claim of complete OS isolation: production still requires a
non-root service account, seccomp/container orchestration, network egress
rules, reverse-proxy TLS, operational monitoring, and actual converter QA.
"""
from __future__ import annotations

import os
import shutil
import subprocess
import sys
from dataclasses import dataclass
from pathlib import Path
from functools import lru_cache

from cloud.process_limits import readiness as limits_readiness, required as limits_required, ProcessLimits


@lru_cache(maxsize=2)
def probe_bubblewrap(executable: str) -> bool:
    """Test user/pid/net/mount namespaces, not merely the binary's presence."""
    if not executable or not Path(executable).is_file() or not os.access(executable, os.X_OK):
        return False
    if not Path('/usr/bin/true').is_file():
        return False
    argv = [executable, '--die-with-parent', '--unshare-all', '--new-session',
            '--ro-bind', '/usr', '/usr', '--proc', '/proc', '--dev', '/dev',
            '--tmpfs', '/tmp', '--', '/usr/bin/true']
    try:
        result = subprocess.run(argv, stdin=subprocess.DEVNULL,
                                stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                                env={'PATH': '/usr/bin:/bin', 'LANG': 'C'},
                                timeout=3, check=False)
        return result.returncode == 0
    except (OSError, subprocess.TimeoutExpired):
        return False


def isolation_readiness(timeout_seconds: int = 120, *, dev_http: bool = False) -> dict:
    state = dict(limits_readiness(timeout_seconds))
    if dev_http:
        state.update(mode='dev-resource-limits', sandbox_ready=False,
                     isolated_network=False, isolated_workspace=False,
                     reason=state['reason'] if not state['ready'] else 'DEV_ONLY_NOT_SANDBOXED')
        return state
    candidate = shutil.which('bwrap') if sys.platform.startswith('linux') else None
    sandbox_ready = bool(candidate and probe_bubblewrap(candidate))
    state['ready'] = bool(state['ready'] and sandbox_ready)
    state.update(mode='production-bubblewrap', sandbox_ready=sandbox_ready,
                 isolated_network=sandbox_ready, isolated_workspace=sandbox_ready,
                 reason='READY_WITH_NAMESPACE_ISOLATION' if state['ready'] else 'PRODUCTION_SANDBOX_UNAVAILABLE')
    # Namespace isolation alone is not a complete production security boundary.
    state['is_full_sandbox'] = False
    return state


@dataclass(frozen=True)
class IsolatedLimits:
    limits: ProcessLimits
    bubblewrap: str

    def wrap(self, args: list[str], *, executable: Path, workspace: Path) -> list[str]:
        """Expose only workspace (writable) and runtime directories (read-only).

        All host input/output paths are rewritten to a fixed in-namespace
        /work path, never interpolated into a shell command.
        """
        if Path(executable).is_symlink():
            raise ValueError('EXECUTABLE_SYMLINK')
        workspace = Path(workspace).resolve(strict=True)
        executable = Path(executable).resolve(strict=True)
        if not workspace.is_dir() or not executable.is_file() or executable.is_symlink():
            raise ValueError('INVALID_ISOLATED_EXECUTABLE_OR_WORKSPACE')
        if len(args) != 5 or Path(args[0]).resolve() != executable or args[1] != 'export-pdf' or args[3] != '-o':
            raise ValueError('UNEXPECTED_RHWP_ARGV')
        if Path(args[2]).is_symlink() or Path(args[4]).is_symlink():
            raise ValueError('INPUT_OUTPUT_SYMLINK')
        source = Path(args[2]).resolve(strict=True)
        output = Path(args[4]).resolve(strict=False)
        try:
            in_name = source.relative_to(workspace)
            out_name = output.relative_to(workspace)
        except ValueError as exc:
            raise ValueError('INPUT_OUTPUT_OUTSIDE_WORKSPACE') from exc
        if not source.is_file() or source.is_symlink() or output.is_symlink() or out_name.parent != Path('output'):
            raise ValueError('INVALID_INPUT_OUTPUT_LAYOUT')
        if in_name.name not in {'input.hwp', 'input.hwpx'} or in_name.parent != Path('.'):
            raise ValueError('INVALID_INPUT_LAYOUT')
        if not output.parent.is_dir():
            raise ValueError('OUTPUT_DIRECTORY_MISSING')
        bwrap = [self.bubblewrap, '--die-with-parent', '--unshare-all', '--new-session',
                 '--tmpfs', '/', '--dir', '/usr', '--dir', '/etc', '--dir', '/work',
                 '--dir', '/opt', '--dir', '/opt/sunrise', '--proc', '/proc',
                 '--dev', '/dev', '--tmpfs', '/tmp']
        # Minimal runtime library and font access; never bind the whole root,
        # host home, project configuration, session DB, or secret files.
        for path in ('/usr', '/bin', '/lib', '/lib64', '/etc/fonts', '/etc/ssl/certs'):
            if Path(path).exists():
                bwrap.extend(['--ro-bind', path, path])
        bwrap.extend(['--ro-bind', str(executable), '/opt/sunrise/rhwp',
                      '--bind', str(workspace), '/work',
                      '--chdir', '/work', '--setenv', 'HOME', '/work',
                      '--setenv', 'TMPDIR', '/tmp', '--setenv', 'XDG_CACHE_HOME', '/tmp',
                      '--', '/opt/sunrise/rhwp', 'export-pdf',
                      '/work/' + in_name.as_posix(), '-o', '/work/' + out_name.as_posix()])
        return self.limits.wrap(bwrap)


def require_isolation(timeout_seconds: int = 120, *, dev_http: bool = False):
    state = isolation_readiness(timeout_seconds, dev_http=dev_http)
    if not state['ready']:
        raise RuntimeError('PROCESS_LIMITS_UNAVAILABLE' if dev_http else 'PRODUCTION_SANDBOX_UNAVAILABLE')
    base = limits_required(timeout_seconds)
    if dev_http:
        return base
    return IsolatedLimits(base, shutil.which('bwrap'))
