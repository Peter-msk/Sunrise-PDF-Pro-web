"""Bounded, read-only HWPX package preflight for untrusted browser uploads.

This is a container sanity check, not an XML, macro, malware, or layout audit.
Never extract the archive and never trust ZIP entry names as filesystem paths.
"""
from __future__ import annotations

import re
import zipfile
from pathlib import Path

MAX_ITEMS = 2048
MAX_TOTAL_UNCOMPRESSED = 128 * 1024 * 1024
MAX_ENTRY_UNCOMPRESSED = 64 * 1024 * 1024
MAX_COMPRESSION_RATIO = 200
ALLOWED_MIMES = {b'application/hwp+zip', b'application/vnd.hancom.hwpx'}


def validate_hwpx_container(path: Path) -> tuple[bool, str]:
    try:
        if not path.is_file() or path.is_symlink():
            return False, 'NOT_A_REGULAR_FILE'
        with zipfile.ZipFile(path, 'r') as archive:
            infos = archive.infolist()
            if not infos or len(infos) > MAX_ITEMS:
                return False, 'ZIP_ENTRY_LIMIT'
            names: set[str] = set()
            total = 0
            for entry in infos:
                raw_name = entry.filename
                # Explicitly deny absolute, traversal, backslash and NUL in all names.
                if (not raw_name or '\\' in raw_name or '\x00' in raw_name
                    or raw_name.startswith('/') or re.match(r'^[A-Za-z]:', raw_name)
                    or any(part in ('', '.', '..') for part in raw_name.rstrip('/').split('/'))):
                    return False, 'UNSAFE_ENTRY_PATH'
                normalized = raw_name.casefold()
                if normalized in names:
                    return False, 'DUPLICATE_ENTRY'
                names.add(normalized)
                # Symbolic links inside UNIX-created zips are rejected even without extraction.
                unix_mode = (entry.external_attr >> 16) & 0o170000
                if entry.create_system == 3 and unix_mode == 0o120000:
                    return False, 'ZIP_SYMLINK'
                if entry.flag_bits & 1:
                    return False, 'ENCRYPTED_ENTRY'
                if entry.compress_type not in (zipfile.ZIP_STORED, zipfile.ZIP_DEFLATED):
                    return False, 'UNSUPPORTED_COMPRESSION'
                total += entry.file_size
                if entry.file_size > MAX_ENTRY_UNCOMPRESSED or total > MAX_TOTAL_UNCOMPRESSED:
                    return False, 'ZIP_EXPANSION_LIMIT'
                if entry.file_size > 1024 * 1024 and entry.file_size / max(entry.compress_size, 1) > MAX_COMPRESSION_RATIO:
                    return False, 'ZIP_COMPRESSION_RATIO'
            required = {'mimetype', 'contents/content.hpf', 'contents/header.xml'}
            if not required.issubset(names) or not any(
                re.fullmatch(r'contents/section\d+\.xml', n) for n in names
            ):
                return False, 'HWPX_REQUIRED_PARTS_MISSING'
            first = infos[0]
            if first.filename.casefold() != 'mimetype' or first.compress_type != zipfile.ZIP_STORED or first.file_size > 128:
                return False, 'HWPX_MIMETYPE_ORDER'
            if archive.read(first).strip() not in ALLOWED_MIMES:
                return False, 'INVALID_HWPX_MIMETYPE'
            # Check only required small entries' CRC, never decompress large embedded files.
            for target in ('Contents/content.hpf', 'Contents/header.xml'):
                item = next((i for i in infos if i.filename.casefold() == target.casefold()), None)
                if item is None or item.file_size == 0 or item.file_size > 4 * 1024 * 1024:
                    return False, 'HWPX_REQUIRED_PART_INVALID'
                with archive.open(item) as src:
                    remaining = item.file_size
                    while remaining > 0:
                        chunk = src.read(min(65536, remaining))
                        if not chunk:
                            return False, 'HWPX_TRUNCATED'
                        remaining -= len(chunk)
            return True, 'VALID_CONTAINER_STRUCTURE'
    except (OSError, ValueError, RuntimeError, zipfile.BadZipFile, EOFError, KeyError, OverflowError):
        return False, 'CORRUPT_ZIP'
