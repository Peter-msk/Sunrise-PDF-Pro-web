"""SQLite-backed durable job metadata for the single-worker R22 staging service.

No password or session cookies are persisted. Database rows never contain arbitrary
filesystem paths: paths are reconstructed solely from validated owner and job IDs.
"""
from __future__ import annotations

import sqlite3
import threading
from pathlib import Path

SCHEMA = """
CREATE TABLE IF NOT EXISTS jobs (
 id TEXT PRIMARY KEY,
 owner TEXT NOT NULL,
 original_name TEXT NOT NULL,
 created REAL NOT NULL,
 state TEXT NOT NULL,
 percent INTEGER NOT NULL DEFAULT 0,
 error TEXT NOT NULL DEFAULT '',
 digest TEXT NOT NULL DEFAULT '',
 pages INTEGER NOT NULL DEFAULT 0,
 source_sha256 TEXT NOT NULL DEFAULT ''
);
CREATE INDEX IF NOT EXISTS jobs_by_owner ON jobs(owner, created DESC);
"""


class JobStore:
    """Short, synchronous, transactional operations; one process/ASGI worker only."""
    def __init__(self, path: Path):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._lock = threading.RLock()
        with self._connect() as db:
            db.executescript(SCHEMA)

    def _connect(self):
        db = sqlite3.connect(str(self.path), timeout=10)
        db.execute('PRAGMA busy_timeout=10000')
        return db

    def save(self, job):
        with self._lock, self._connect() as db:
            db.execute('''INSERT INTO jobs
                (id,owner,original_name,created,state,percent,error,digest,pages,source_sha256)
                VALUES (?,?,?,?,?,?,?,?,?,?)
                ON CONFLICT(id) DO UPDATE SET
                owner=excluded.owner,original_name=excluded.original_name,
                created=excluded.created,state=excluded.state,percent=excluded.percent,
                error=excluded.error,digest=excluded.digest,pages=excluded.pages,
                source_sha256=excluded.source_sha256''',
                (job.id,job.owner,job.original_name,job.created,job.state,job.percent,
                 job.error,job.digest,job.pages,job.source_sha256))

    def remove(self, job_id: str):
        with self._lock, self._connect() as db:
            db.execute('DELETE FROM jobs WHERE id=?', (job_id,))

    def load(self):
        with self._lock, self._connect() as db:
            return db.execute('''SELECT id,owner,original_name,created,state,percent,
                error,digest,pages,source_sha256 FROM jobs ORDER BY created DESC''').fetchall()
