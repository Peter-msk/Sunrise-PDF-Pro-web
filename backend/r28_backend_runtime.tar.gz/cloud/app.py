"""R24: resource-limited SQLite-durable authenticated staging API for browser-first HWP/HWPX to PDF.

This application deliberately does NOT expose the old localhost single-user API.
A verified rhwp executable must be installed by the service OPERATOR.
Single ASGI worker staging scope; sessions are ephemeral, job metadata is durable.
"""
from __future__ import annotations

import hashlib
from contextlib import asynccontextmanager
import hmac
import json
import os
import re
import secrets
import shutil
import sys
import threading
import time
import uuid
import zipfile
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass, field
from pathlib import Path
from urllib.parse import urlsplit

from fastapi import FastAPI, File, HTTPException, Request, UploadFile
from fastapi.responses import FileResponse, HTMLResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel
from starlette.middleware.trustedhost import TrustedHostMiddleware

PROJECT = Path(__file__).resolve().parents[1]
CORE = PROJECT / 'web'
if str(CORE) not in sys.path:
    sys.path.insert(0, str(CORE))
from opensource_converter import convert as rhwp_convert, binary_path
from rhwp_assets import check_assets
from rhwp_preview import _is_hwp_signature
from pdf_result_guard import InvalidToolOutput, validate_java_result
from cloud.job_store import JobStore
from cloud.hwpx_guard import validate_hwpx_container
from cloud.worker_isolation import isolation_readiness as process_readiness, require_isolation
from cloud.rhwp_contract import verify_cli_contract
from cloud.edge_auth import EdgeAuthenticator

MAX_FILE = 20 * 1024 * 1024
MAX_ACCOUNT_JOBS = 10
MAX_TOTAL_JOBS = 50
SESSION_SECONDS = 8 * 3600
STORAGE_SECONDS = 24 * 3600
USER_RE = re.compile(r'^[a-zA-Z0-9_.-]{3,48}$')
TERMINAL = {'completed', 'failed', 'cancelled', 'interrupted'}


def make_password(password: str, salt: str | None = None) -> str:
    salt = salt or secrets.token_hex(16)
    derived = hashlib.pbkdf2_hmac('sha256', password.encode('utf-8'), bytes.fromhex(salt), 310_000)
    return f'pbkdf2_sha256$310000${salt}${derived.hex()}'


def check_password(password: str, encoded: str) -> bool:
    try:
        algorithm, rounds, salt, digest = encoded.split('$')
        if algorithm != 'pbkdf2_sha256' or int(rounds) != 310_000 or len(salt) != 32 or len(digest) != 64:
            return False
        actual = make_password(password, salt).split('$')[-1]
        return hmac.compare_digest(actual, digest)
    except (ValueError, TypeError):
        return False


@dataclass
class Config:
    data: Path
    users: dict[str, str]
    origin: str
    dev_http: bool = False
    enabled: bool = False
    timeout: int = 120
    edge_required: bool = True

    @classmethod
    def environment(cls):
        origin = os.getenv('SUNRISE_WEB_PUBLIC_ORIGIN', '').rstrip('/')
        dev_http = os.getenv('SUNRISE_WEB_DEV_HTTP') == '1'
        users = {}
        filename = os.getenv('SUNRISE_WEB_USERS_FILE', '')
        if filename:
            f = Path(filename)
            if f.is_file():
                users = json.loads(f.read_text(encoding='utf-8'))
        allowed = bool(origin and urlsplit(origin).scheme in ({'http','https'} if dev_http else {'https'})
                       and urlsplit(origin).hostname and (not dev_http or urlsplit(origin).hostname in {'127.0.0.1', 'localhost', 'testserver'}) and isinstance(users, dict) and users
                       and all(USER_RE.fullmatch(k) and isinstance(v, str) for k,v in users.items()))
        return cls(data=Path(os.getenv('SUNRISE_WEB_DATA', str(PROJECT/'cloud-data'))).resolve(),
                   users=users, origin=origin, dev_http=dev_http, enabled=allowed)


@dataclass
class WebJob:
    id: str
    owner: str
    root: Path
    original_name: str
    created: float
    state: str = 'queued'
    percent: int = 0
    error: str = ''
    digest: str = ''
    source_sha256: str = ''
    pages: int = 0
    cancel: threading.Event = field(default_factory=threading.Event, repr=False)

    def public(self):
        return {'id':self.id, 'file':self.original_name, 'created':self.created,
                'state':self.state, 'percent':self.percent, 'error':self.error,
                'pages':self.pages, 'retryable': self.state in {'failed','cancelled','interrupted'} and bool(self.source_sha256), 'download': f'/api/jobs/{self.id}/pdf' if self.state=='completed' else None}


class Login(BaseModel):
    username: str
    password: str


def engine_deployment_digest_ok(binary: Path | None, *, dev_http: bool) -> bool:
    """Production: match a pinned, operator-supplied build digest before trusting a CLI.

    A digest match does NOT independently prove upstream authenticity; the pin
    MUST originate from the SHA-verified vendor release acquisition pipeline.
    Local test stubs remain supported only in explicit dev-http mode.
    """
    if binary is None:
        return False
    if dev_http:
        return True
    expected = os.environ.get('SUNRISE_RHWP_SHA256', '').strip().lower()
    if re.fullmatch(r'[0-9a-f]{64}', expected) is None:
        return False
    try:
        if binary.is_symlink() or not binary.is_file():
            return False
        with binary.open('rb') as stream:
            actual = hashlib.file_digest(stream, 'sha256').hexdigest()
        return hmac.compare_digest(expected, actual)
    except (OSError, ValueError):
        return False


def create_app(conf: Config | None = None):
    conf = conf or Config.environment()
    @asynccontextmanager
    async def lifespan(app):
        try:
            yield
        finally:
            shutdown()
    app = FastAPI(title='Sunrise PDF PRO Web R27 staging', docs_url=None, redoc_url=None, openapi_url=None,
                  lifespan=lifespan)
    expected_host = urlsplit(conf.origin).netloc.split(':')[0].lower() if conf.origin else 'localhost'
    # The public origin is the Cloudflare Worker hostname, whereas the TLS
    # upstream Host is the dedicated backend hostname. Never allow arbitrary hosts.
    backend_host = os.getenv('SUNRISE_WEB_BACKEND_HOST', '').strip().lower()
    extra_host = [backend_host] if (backend_host and not conf.dev_http and
                                   re.fullmatch(r'[a-z0-9.-]{1,253}', backend_host) and
                                   not backend_host.startswith('.') and ':' not in backend_host) else []
    app.add_middleware(TrustedHostMiddleware,
                       allowed_hosts=[expected_host, 'testserver'] if (conf.dev_http or not conf.enabled)
                       else [expected_host, *extra_host])

    # Production backend must reject requests not authenticated by our Worker.
    # This includes direct-backend requests with forged Origin headers.
    edge = EdgeAuthenticator(os.getenv('SUNRISE_EDGE_HMAC_SECRET', ''))

    @app.middleware('http')
    async def edge_gateway_auth(req: Request, call_next):
        if conf.enabled and not conf.dev_http and conf.edge_required and req.url.path.startswith('/api/'):
            status = edge.authorize(req.method, req.url.path,
                                    req.url.query, req.headers)
            if status is not None:
                return JSONResponse({'detail': status}, status_code=403 if status != 'EDGE_SECRET_NOT_CONFIGURED' else 503,
                                    headers={'Cache-Control': 'no-store'})
        return await call_next(req)

    app.mount('/web', StaticFiles(directory=PROJECT/'cloud'/'static'), name='web')
    # Existing browser WASM loader imports /static/rhwp-wasm-worker.js and vendor files.
    app.mount('/static', StaticFiles(directory=PROJECT/'web'/'static'), name='engine_static')
    lock = threading.RLock()
    sessions: dict[str, tuple[str, str, float]] = {}
    jobs: dict[str, WebJob] = {}
    attempts: dict[str, list[float]] = {}
    pool = ThreadPoolExecutor(max_workers=1, thread_name_prefix='sunrise-rhwp')
    closing = threading.Event()
    inflight: set[str] = set()
    store = JobStore(conf.data / 'web-jobs.sqlite3') if conf.enabled else None

    def save(job):
        if store is not None:
            store.save(job)

    def restore():
        if store is None:
            return
        for row in store.load():
            jid, owner, name, created, state, percent, error, digest, pages, source_sha256 = row
            if not re.fullmatch(r'[0-9a-f]{32}', jid) or not USER_RE.fullmatch(owner):
                continue
            owner_hash = hashlib.sha256(owner.encode()).hexdigest()[:24]
            root = conf.data / 'jobs' / owner_hash / jid
            if root.is_symlink() or not root.is_dir():
                continue
            job = WebJob(jid, owner, root, name, created, state, percent, error,
                         digest, source_sha256, pages)
            if job.state not in TERMINAL:
                job.state='interrupted'
                job.error='SERVER_RESTART_RETRY_REQUIRED'
                save(job)
            jobs[jid] = job

    restore()
    last_purge = 0.0

    def purge_expired():
        # Opportunistic 24h garbage collection; no storage directory is publicly served.
        nonlocal last_purge
        now = time.time()
        with lock:
            if now - last_purge < 30: return
            last_purge = now
            stale_sessions = [sid for sid, value in sessions.items() if value[2] <= now]
            for sid in stale_sessions: sessions.pop(sid, None)
            stale_jobs = [j for j in jobs.values() if now - j.created > STORAGE_SECONDS and j.state in TERMINAL]
            for j in stale_jobs:
                jobs.pop(j.id, None)
                if store: store.remove(j.id)
            active_roots = {j.root.resolve() for j in jobs.values()}
        for job in stale_jobs:
            shutil.rmtree(job.root, ignore_errors=True)
        storage = conf.data / 'jobs'
        if storage.is_dir():
            for account_dir in storage.iterdir():
                if account_dir.is_symlink() or not account_dir.is_dir(): continue
                for folder in account_dir.iterdir():
                    if (not folder.is_symlink() and folder.is_dir() and re.fullmatch(r'[0-9a-f]{32}',folder.name)
                        and folder.resolve() not in active_roots and now-folder.stat().st_mtime>STORAGE_SECONDS):
                        shutil.rmtree(folder,ignore_errors=True)

    def configured():
        if not conf.enabled:
            raise HTTPException(503, 'WEB_SERVICE_NOT_CONFIGURED')

    def origin_check(req: Request):
        configured()
        origin = req.headers.get('origin')
        if origin != conf.origin:
            raise HTTPException(403, 'ORIGIN_DENIED')
        # HTTPS termination is handled by the trusted reverse proxy in production.
        if not conf.dev_http and urlsplit(conf.origin).scheme != 'https':
            raise HTTPException(503, 'HTTPS_REQUIRED')

    def user_of(req: Request, *, write=False):
        configured()
        sid = req.cookies.get('sunrise_session', '')
        with lock:
            session = sessions.get(sid)
        if not session or session[2] <= time.time():
            raise HTTPException(401, 'LOGIN_REQUIRED')
        if write:
            origin_check(req)
            if not hmac.compare_digest(req.headers.get('x-sunrise-csrf',''), session[1]):
                raise HTTPException(403, 'CSRF_DENIED')
        return session[0], session[1]

    def job_for(req: Request, job_id: str, *, write=False):
        user, _ = user_of(req, write=write)
        with lock:
            job = jobs.get(job_id)
        if not job or job.owner != user:
            raise HTTPException(404, 'JOB_NOT_FOUND')
        return job

    def safe_hwpx(path: Path):
        return validate_hwpx_container(path)[0]

    def process(job: WebJob):
        with lock: inflight.add(job.id)
        out = job.root / 'output'
        pause = threading.Event(); pause.set()
        try:
            with lock:
                if closing.is_set():
                    job.state='interrupted'; job.error='SERVER_SHUTDOWN'; save(job); return
                if job.cancel.is_set():
                    job.state='cancelled'; save(job); return
                job.state='running'; job.error=''; save(job)
            # Never consume an input that changed after upload (or since last retry).
            candidates = list(job.root.glob('input.*'))
            if len(candidates) != 1 or candidates[0].is_symlink() or not job.source_sha256:
                raise InvalidToolOutput('INPUT_NOT_VERIFIED')
            source = candidates[0]
            with source.open('rb') as input_stream:
                current_sha = hashlib.file_digest(input_stream,'sha256').hexdigest()
            if not hmac.compare_digest(job.source_sha256, current_sha):
                raise InvalidToolOutput('INPUT_DIGEST_MISMATCH')
            out.mkdir(exist_ok=True)
            def progress(value):
                with lock:
                    n=min(95,max(0,int(value*95)))
                    if n != job.percent and job.state=='running' and not closing.is_set():
                        job.percent=n
                        save(job)
            result = rhwp_convert([source], out, stop_event=job.cancel, pause_event=pause,
                                  on_file=lambda p,s: None, on_progress=progress,
                                  timeout_seconds=conf.timeout,
                                  process_limits=require_isolation(conf.timeout, dev_http=conf.dev_http))
            if closing.is_set():
                with lock: job.state='interrupted'; job.error='SERVER_SHUTDOWN'; save(job)
                return
            if job.cancel.is_set() or result.stopped:
                with lock: job.state='cancelled'; save(job)
                return
            output_paths = [Path(p) for p in result.output_paths]
            if result.success_count != 1 or result.fail_count or len(output_paths) != 1:
                with lock: job.state='failed'; job.error='RHWP_CONVERSION_FAILED'; save(job)
                return
            pdf = output_paths[0]
            if pdf.parent.resolve() != out.resolve() or pdf.is_symlink():
                raise InvalidToolOutput('PDF_OUTPUT_OUTSIDE_WORKSPACE')
            info = validate_java_result(pdf, 'pdf')
            with pdf.open('rb') as pdf_stream:
                digest = hashlib.file_digest(pdf_stream,'sha256').hexdigest()
            if closing.is_set():
                with lock: job.state='interrupted'; job.error='SERVER_SHUTDOWN'; save(job)
                return
            if job.cancel.is_set():
                with lock: job.state='cancelled'; job.error='USER_CANCELLED'; save(job)
                return
            pdf.replace(out/'result.pdf')
            with lock:
                job.digest=digest; job.pages=info['pages']; job.state='completed'; job.percent=100;save(job)
        except Exception:
            with lock:
                job.state='interrupted' if closing.is_set() else 'failed'
                job.error='SERVER_SHUTDOWN' if closing.is_set() else 'RHWP_CONVERSION_OR_PDF_VALIDATION_FAILED'
                save(job)
        finally:
            with lock:
                cleanup=job.state != 'completed'
            if cleanup:
                shutil.rmtree(out, ignore_errors=True)
            with lock: inflight.discard(job.id)

    @app.middleware('http')
    async def headers(request: Request, call_next):
        if request.url.path.startswith('/api/'):
            purge_expired()
        response = await call_next(request)
        response.headers['X-Content-Type-Options'] = 'nosniff'
        response.headers['Referrer-Policy'] = 'no-referrer'
        response.headers['X-Frame-Options'] = 'DENY'
        response.headers['Cache-Control'] = 'no-store'
        response.headers['Content-Security-Policy'] = ("default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' blob: data:; "
                                                      "worker-src 'self'; connect-src 'self'; object-src 'none'; base-uri 'none'; frame-ancestors 'none'")
        if not conf.dev_http: response.headers['Strict-Transport-Security'] = 'max-age=31536000'
        return response

    @app.get('/')
    def index():
        return FileResponse(PROJECT/'cloud'/'static'/'index.html', media_type='text/html')

    @app.get('/api/health')
    def health():
        return {'service':'sunrise-r25','configured':conf.enabled,'status':'staging',
                'durable_jobs':store is not None,'process_limits':process_readiness(conf.timeout, dev_http=conf.dev_http)}

    @app.post('/api/auth/login')
    def login(req: Request, body: Login):
        origin_check(req)
        now = time.time()
        client = str(req.client.host if req.client else 'unknown')[:100]
        if len(body.username)>64 or len(body.password)>256:
            raise HTTPException(400, 'INVALID_LOGIN')
        with lock:
            recent = [x for x in attempts.get(client,[]) if now-x<300]
            if len(recent) >= 8: raise HTTPException(429,'LOGIN_RATE_LIMIT')
            attempts[client] = (recent+[now])[-8:]
        encoded = conf.users.get(body.username, '')
        if not encoded or not check_password(body.password,encoded):
            raise HTTPException(401,'INVALID_CREDENTIALS')
        sid, csrf = secrets.token_urlsafe(36), secrets.token_urlsafe(32)
        with lock:
            sessions[sid]=(body.username,csrf,now+SESSION_SECONDS)
            attempts.pop(client,None)
        response = JSONResponse({'user':body.username,'csrf':csrf,'session_minutes':480})
        response.set_cookie('sunrise_session',sid,httponly=True,secure=not conf.dev_http,samesite='strict',path='/',max_age=SESSION_SECONDS)
        return response

    @app.get('/api/session')
    def session(req: Request):
        username,csrf=user_of(req)
        return {'user':username,'csrf':csrf}

    @app.post('/api/auth/logout')
    def logout(req: Request):
        user_of(req,write=True)
        sid=req.cookies.get('sunrise_session','')
        with lock: sessions.pop(sid,None)
        res=JSONResponse({'ok':True});res.delete_cookie('sunrise_session',path='/');return res

    def converter_readiness():
        """One production contract gate shared by UI status, upload and retry.

        Development HTTP intentionally retains synthetic CLI compatibility for
        regression tests; it MUST NOT claim real upstream verification.
        """
        binary = binary_path()
        digest_ok = engine_deployment_digest_ok(binary, dev_http=conf.dev_http)
        if binary is None:
            return {'ready':False, 'binary':None, 'digest_ok':False,
                    'contract_ok':False, 'contract_reason':'RHWP_ENGINE_NOT_INSTALLED_ON_SERVER'}
        if not digest_ok:
            return {'ready':False, 'binary':binary, 'digest_ok':False,
                    'contract_ok':False, 'contract_reason':'RHWP_DEPLOYMENT_SHA256_UNVERIFIED'}
        if conf.dev_http:
            return {'ready':True, 'binary':binary, 'digest_ok':True,
                    'contract_ok':False, 'contract_reason':'DEV_STUB_MODE_NOT_VERIFIED'}
        result = verify_cli_contract(binary, os.environ.get('SUNRISE_RHWP_SHA256',''),
                                     os.environ.get('SUNRISE_RHWP_EXPECTED_VERSION','0.8.7'))
        return {'ready':result['verified'], 'binary':binary, 'digest_ok':True,
                'contract_ok':result['verified'], 'contract_reason':result['reason'],
                'contract_version':result.get('version')}

    @app.get('/api/status')
    def status(req: Request):
        user_of(req)
        engine = converter_readiness()
        wasm = check_assets(PROJECT/'web'/'static'/'vendor'/'rhwp')
        return {'rhwp_cli_available':engine['ready'],
                'rhwp_cli_file_present':bool(engine['binary']),
                'rhwp_deployment_digest_verified':bool(engine['binary'] and not conf.dev_http and engine['digest_ok']),
                'rhwp_cli_contract_verified':engine['contract_ok'],
                'rhwp_cli_contract_reason':engine['contract_reason'],
                'rhwp_cli_reported_version':engine.get('contract_version'),
                'process_limits':process_readiness(conf.timeout, dev_http=conf.dev_http),
                'wasm_assets_verified':bool(wasm['integrity_verified']),
                'actual_conversion_verified':False,'max_upload_bytes':MAX_FILE,'user_install_required':False}

    @app.get('/api/jobs')
    def list_jobs(req: Request):
        user,_=user_of(req)
        with lock:
            return {'jobs':[j.public() for j in sorted(jobs.values(),key=lambda j:j.created,reverse=True) if j.owner==user]}

    @app.post('/api/jobs',status_code=202)
    async def upload(req: Request, file: UploadFile=File(...)):
        user,_=user_of(req,write=True)
        engine = converter_readiness()
        if engine['binary'] is None:
            raise HTTPException(503, 'RHWP_ENGINE_NOT_INSTALLED_ON_SERVER')
        if not process_readiness(conf.timeout, dev_http=conf.dev_http)['ready']:
            raise HTTPException(503, 'PROCESS_LIMITS_UNAVAILABLE' if conf.dev_http else 'PRODUCTION_SANDBOX_UNAVAILABLE')
        if not engine['ready']:
            raise HTTPException(503, engine['contract_reason'])
        name=(file.filename or '').replace('\\','/').split('/')[-1]
        suffix=Path(name).suffix.lower()
        if suffix not in {'.hwp','.hwpx'} or not name or len(name)>150:
            raise HTTPException(400,'HWP_HWPX_REQUIRED')
        with lock:
            owned=sum(j.owner==user for j in jobs.values())
            if owned>=MAX_ACCOUNT_JOBS or len(jobs)>=MAX_TOTAL_JOBS:
                raise HTTPException(429,'JOB_QUOTA_EXCEEDED')
            job_id=uuid.uuid4().hex
            safe_user=hashlib.sha256(user.encode()).hexdigest()[:24]
            root=conf.data/'jobs'/safe_user/job_id
            root.mkdir(parents=True,exist_ok=False)
            job=WebJob(job_id,user,root,name,time.time())
            jobs[job_id]=job
        source=root/f'input{suffix}'
        try:
            total=0
            with source.open('xb') as handle:
                while block:=await file.read(1024*1024):
                    total+=len(block)
                    if total>MAX_FILE: raise HTTPException(413,'MAX_UPLOAD_20MIB')
                    handle.write(block)
            with source.open('rb') as handle:
                signature=handle.read(8)
                handle.seek(0)
                job.source_sha256=hashlib.file_digest(handle,'sha256').hexdigest()
            if total == 0 or not _is_hwp_signature(signature, suffix):
                raise HTTPException(422, 'INVALID_HWP_SIGNATURE_OR_ARCHIVE')
            if suffix == '.hwpx':
                valid, reason = validate_hwpx_container(source)
                if not valid:
                    raise HTTPException(422, 'INVALID_HWPX_' + reason)
            with lock: save(job)
            pool.submit(process,job)
            return job.public()
        except Exception:
            with lock:
                jobs.pop(job_id,None)
                if store: store.remove(job_id)
            shutil.rmtree(root,ignore_errors=True)
            raise
        finally:
            await file.close()

    @app.get('/api/jobs/{job_id}')
    def get_job(job_id: str,req:Request):
        return job_for(req,job_id).public()

    @app.post('/api/jobs/{job_id}/cancel')
    def cancel(job_id: str,req:Request):
        job=job_for(req,job_id,write=True)
        with lock:
            if job.state in {'queued','running'}:
                job.cancel.set()
                save(job)
        return job.public()

    @app.get('/api/jobs/{job_id}/pdf')
    def download(job_id: str,req:Request):
        job=job_for(req,job_id)
        with lock:
            if job.state!='completed': raise HTTPException(409,'JOB_NOT_COMPLETED')
            digest=job.digest
        pdf=job.root/'output'/'result.pdf'
        if pdf.is_symlink() or not pdf.is_file(): raise HTTPException(409,'RESULT_MISSING')
        with pdf.open('rb') as stream: actual=hashlib.file_digest(stream,'sha256').hexdigest()
        if not hmac.compare_digest(digest,actual): raise HTTPException(409,'RESULT_DIGEST_MISMATCH')
        return FileResponse(pdf,media_type='application/pdf',filename=f'sunrise-{job.id[:12]}.pdf',
                            headers={'Content-Security-Policy':"default-src 'none'; sandbox"})

    @app.delete('/api/jobs/{job_id}')
    def delete(job_id: str,req:Request):
        job=job_for(req,job_id,write=True)
        with lock:
            if job.state not in TERMINAL: raise HTTPException(409,'JOB_STILL_ACTIVE')
            jobs.pop(job_id,None)
            if store: store.remove(job_id)
        shutil.rmtree(job.root,ignore_errors=True)
        return {'ok':True}

    @app.post('/api/jobs/{job_id}/retry', status_code=202)
    def retry(job_id: str, req: Request):
        job=job_for(req, job_id, write=True)
        engine = converter_readiness()
        if engine['binary'] is None:
            raise HTTPException(503, 'RHWP_ENGINE_NOT_INSTALLED_ON_SERVER')
        if not process_readiness(conf.timeout, dev_http=conf.dev_http)['ready']:
            raise HTTPException(503, 'PROCESS_LIMITS_UNAVAILABLE' if conf.dev_http else 'PRODUCTION_SANDBOX_UNAVAILABLE')
        if not engine['ready']:
            raise HTTPException(503, engine['contract_reason'])
        with lock:
            if job.state not in {'interrupted','failed','cancelled'} or job.id in inflight:
                raise HTTPException(409, 'JOB_NOT_RETRYABLE')
            candidates=list(job.root.glob('input.*'))
            if len(candidates)!=1 or candidates[0].is_symlink() or not job.source_sha256:
                raise HTTPException(409,'INPUT_NOT_VERIFIED')
            with candidates[0].open('rb') as stream:
                digest=hashlib.file_digest(stream,'sha256').hexdigest()
            if not hmac.compare_digest(digest,job.source_sha256):
                raise HTTPException(409,'INPUT_DIGEST_MISMATCH')
            shutil.rmtree(job.root/'output',ignore_errors=True)
            job.cancel=threading.Event()
            job.state='queued';job.percent=0;job.error='';job.digest='';job.pages=0
            save(job)
            try:
                pool.submit(process,job)
            except RuntimeError:
                job.state='interrupted';job.error='WORKER_UNAVAILABLE';save(job)
                raise HTTPException(503,'WORKER_UNAVAILABLE')
        return job.public()

    def shutdown():
        closing.set()
        with lock:
            for job in jobs.values():
                if job.state in {'queued','running'}:
                    job.cancel.set()
                    job.state='interrupted'
                    job.error='SERVER_SHUTDOWN'
                    save(job)
        pool.shutdown(wait=True,cancel_futures=True)

    app.state.cloud_store=store
    app.state.cloud_jobs=jobs
    app.state.cloud_sessions=sessions
    app.state.cloud_pool=pool
    return app


app=create_app()
