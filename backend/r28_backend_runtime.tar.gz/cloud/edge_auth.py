"""Fail-closed Cloudflare Worker → Linux backend request authentication.

HMAC signs timestamp, nonce, request method and exact path/query. HTTPS protects
request bodies in transit; replay nonces are cached for a single ASGI worker.
This check complements cookie/CSRF auth, it does not replace user authorization.
"""
from __future__ import annotations

import hashlib
import hmac
import re
import threading
import time

class EdgeAuthenticator:
    def __init__(self, secret: str, *, now=None):
        self._secret = secret.encode('utf-8') if len(secret) >= 32 else b''
        self._now = now or time.time
        self._used: dict[str, int] = {}
        self._lock = threading.Lock()

    @staticmethod
    def canonical(timestamp: str, nonce: str, method: str, path: str, query: str) -> bytes:
        suffix = '?' + query if query else ''
        return f'{timestamp}\n{nonce}\n{method.upper()}\n{path}{suffix}'.encode('utf-8')

    def authorize(self, method: str, path: str, query: str, headers) -> str | None:
        if not self._secret:
            return 'EDGE_SECRET_NOT_CONFIGURED'
        timestamp = headers.get('x-sunrise-edge-time', '')
        nonce = headers.get('x-sunrise-edge-nonce', '')
        signature = headers.get('x-sunrise-edge-signature', '')
        if not re.fullmatch(r'[0-9]{10,11}', timestamp) or not re.fullmatch(r'[0-9a-f]{32}', nonce):
            return 'EDGE_AUTH_REQUIRED'
        if not re.fullmatch(r'[0-9a-f]{64}', signature):
            return 'EDGE_AUTH_REQUIRED'
        now = int(self._now())
        if abs(int(timestamp) - now) > 45:
            return 'EDGE_SIGNATURE_EXPIRED'
        expected = hmac.new(self._secret, self.canonical(timestamp, nonce, method, path, query), hashlib.sha256).hexdigest()
        if not hmac.compare_digest(signature, expected):
            return 'EDGE_SIGNATURE_INVALID'
        with self._lock:
            expired = [n for n, deadline in self._used.items() if deadline <= now]
            for n in expired:
                self._used.pop(n, None)
            if nonce in self._used:
                return 'EDGE_REPLAY_DENIED'
            if len(self._used) >= 8192:
                return 'EDGE_AUTH_CAPACITY_EXCEEDED'
            self._used[nonce] = now + 47
        return None
