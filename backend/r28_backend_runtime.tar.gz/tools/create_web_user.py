"""Operator-only command for provisioning isolated web accounts. No password CLI args."""
import argparse
import getpass
import json
import os
import re
import secrets
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from cloud.app import make_password


def main():
    p=argparse.ArgumentParser(description='R21 web staging account provisioning')
    p.add_argument('--users-file',required=True)
    p.add_argument('--username',required=True)
    p.add_argument('--password-stdin',action='store_true',help='Read one password line from stdin (for automated secrets provisioner)')
    args=p.parse_args()
    if not re.fullmatch(r'[A-Za-z0-9_.-]{3,48}',args.username):
        raise SystemExit('계정명은 영문·숫자·._- 3~48자만 허용됩니다')
    raw=sys.stdin.readline().rstrip('\r\n') if args.password_stdin else getpass.getpass('새 계정 비밀번호: ')
    if len(raw)<12 or len(raw)>256:raise SystemExit('비밀번호는 12~256자로 지정하세요')
    target=Path(args.users_file).resolve()
    if target.exists() and target.is_symlink():raise SystemExit('심볼릭 링크 사용 불가')
    current=json.loads(target.read_text(encoding='utf-8')) if target.exists() else {}
    if not isinstance(current,dict):raise SystemExit('기존 사용자 파일이 JSON 객체가 아닙니다')
    if args.username in current:raise SystemExit('이미 등록된 사용자입니다. 재등록은 관리자 검토가 필요합니다')
    current[args.username]=make_password(raw)
    target.parent.mkdir(parents=True,exist_ok=True)
    temp=target.with_suffix(target.suffix+'.'+secrets.token_hex(6)+'.tmp')
    fd=os.open(temp,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
    try:
        with os.fdopen(fd,'w',encoding='utf-8') as stream:
            json.dump(current,stream,ensure_ascii=False,indent=2)
        os.replace(temp,target)
        if os.name!='nt':os.chmod(target,0o600)
    finally:
        temp.unlink(missing_ok=True)
    print(f'웹 계정 등록 완료: {args.username} (비밀번호 출력 없음)')

if __name__=='__main__':main()
